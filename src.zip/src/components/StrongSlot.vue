<template>
  <strong>
    <slot></slot>
  </strong>
</template>
