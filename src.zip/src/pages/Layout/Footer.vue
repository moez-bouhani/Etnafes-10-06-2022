<template>
  <section id="contact" style="background-color: #fff">
    <div class="section-header">
      <div class="section-title">
        <br />
        <br />
        <center>
          <h3 style="color: #333;" class="d-none d-lg-block">Nos partenaires</h3>
          <h3 class="col d-lg-none" style="color: #333;margin-bottom:0px !important">Nos partenaires</h3>

        </center>
      </div>
      <span class="section-divider"></span>
    </div>
    <div class="container d-none d-lg-block">
      <div class="row wow fadeInUp">
        <div class="col-md-1"></div>
        <div class="col-mx-2">
          <div class="contact-about">
            <span>
              <div>
                <img
                  alt="media web services"
                  class="width_img_footer img_num1"
                  src="/logos/MWS-MEDIA--WEB-SERVICES-tourism--ETNAFES-voyage.jpg"
                />
              </div>
            </span>
          </div>
        </div>
        <div class="col-mx-2">
          <div class="contact-about">
            <span>
              <div>
                <img
                  alt="EDJEF"
                  class="width_img_footer img_num2"
                  src="/logos/EDJEF--ETNAFES-voyage.jpg"
                />
              </div>
            </span>
          </div>
        </div>
        <!-- start up act -->

        <div class="col-mx-2">
          <div class="contact-about">
            <span>
              <div>
                <img
                  alt="Startup Act"
                  class="width_img_start img_num3"
                  src="/start_up_act.png"
                />
              </div>
            </span>
          </div>
        </div>
        <!--  -->
        <div class="col-mx-2">
          <div class="contact-about">
            <span>
              <div>
                <img
                  alt="Tunisia Inspiring"
                  class="width_img_footer img_num4"
                  src="/logos/tourism--ETNAFES-voyage.jpg"
                />
              </div>
            </span>
          </div>
        </div>
      </div>
    </div>
    <br />

    <div class="container d-lg-none">
      <div class="row wow fadeInUp">
        <div class="col">
          <div class="contact-about">
            <span>
              <div>
                <img
                  alt="media web services"
                  class="width_img_footer"
                  src="/logos/MWS-MEDIA--WEB-SERVICES-tourism--ETNAFES-voyage.jpg"
                />
              </div>
            </span>
          </div>
        </div>
        <div class="col">
          <div class="contact-about">
            <span>
              <div>
                <img
                  alt="EDJEF"
                  class="width_img_footer"
                  src="/logos/EDJEF--ETNAFES-voyage.jpg"
                />
              </div>
            </span>
          </div>
        </div>
        <!-- start up act -->

        <div class="col">
          <div class="contact-about">
            <span>
              <div>
                <img
                  alt="Startup Act"
                  class="width_img_start"
                  src="/start_up_act.png"
                />
              </div>
            </span>
          </div>
        </div>
        <!--  -->
        <div class="col">
          <div class="contact-about">
            <span>
              <div>
                <img
                  alt="Tunisia Inspiring"
                  class="width_img_footer"
                  src="/logos/tourism--ETNAFES-voyage.jpg"
                />
              </div>
            </span>
          </div>
        </div>
      </div>
    </div>

    <div
      class="bottom-footer clearfix"
      style="background-color: #f1f1f1; padding-top: 20px; padding-bottom: 20px"
    >
      <p class="float-left">
        &copy; {{ new Date().getFullYear() }}
        <a href="/" class="tran3s p-color">Etnafes</a>. Tous droits
        réservés&nbsp;&nbsp;
        <a href="/conditions_utilisation">Mentions Légales</a>&nbsp;
        <a href="/contact">Contact</a>
      </p>

      <p class="float-right">
        Suivez nous:
        <a href="https://www.facebook.com/ETNAFES/" target="_blank">
          <i class="fab fa-facebook-square"></i> </a
        >&nbsp;
        <a href="https://www.instagram.com/etnafes.tn/" target="_blank">
          <i class="fab fa-instagram"></i>&nbsp;
        </a>
        <a href="https://www.linkedin.com/company/etnafes/about/" target="_blank">
          <i class="fab fa-linkedin"></i> </a
        >&nbsp;&nbsp;&nbsp;
      </p>
    </div>
  </section>
</template>
<style scoped>
/*----------------------- Footer ---------------------*/
footer.bg-one {
  background-color: #fff;
}

footer {
  padding-top: 30px;
}

footer .footer-logo h5 a {
  font-weight: 600;
  font-size: 16px;
  color: #222222;
  margin: 30px 0 15px 0;
}

footer h4 {
  font-size: 20px;
  font-weight: 600;
  margin-bottom: 25px;
}

footer .footer-list ul li {
  line-height: 40px;
  list-style-type: none;
}

footer .footer-list ul li a {
  color: rgba(0, 0, 0, 0.65);
  font-weight: 500;
}

footer .footer-subscribe input {
  width: 100%;
  height: 55px;
  border: 1px solid rgba(0, 0, 0, 0.08);
  border-radius: 5px;
  padding: 0 20px;
  background: transparent;
}

footer .footer-subscribe form {
  padding: 15px 0 35px 0;
}

footer .footer-subscribe ul li {
  display: inline-block;
}

footer .footer-subscribe ul li a {
  color: #b4b5b6;
  font-size: 18px;
  margin-right: 15px;
}

footer .bottom-footer p,
footer .bottom-footer ul li {
  line-height: 40px;
}

footer .bottom-footer p a {
  font-weight: 500;
}

footer .bottom-footer ul li {
  float: left;
  padding-left: 50px;
}

footer .bottom-footer ul li h3 {
  font-size: 24px;
  font-weight: 600;
}

footer .row [class*="col-"] {
  margin-bottom: 0px;
}

footer .bottom-footer {
  /* padding: 25px 0 30px 0; */
  padding: 0px;
}
a {
  font-family: "Poppins", sans-serif;
  font-size: 16px;
}
a:hover,
a:focus,
a:visited {
  text-decoration: none;
  outline: none;
  font-family: "Poppins", sans-serif;
}
h6 {
  font-size: 20px;
  font-weight: normal;
  font-family: "Poppins", sans-serif;
}
p {
  font-family: "Poppins", sans-serif;
  font-weight: normal;
  color: rgba(0, 0, 0, 0.65);
  font-size: 16px;
}
</style>


  <script>
import { VueperSlides, VueperSlide } from "vueperslides";
import "vueperslides/dist/vueperslides.css";
import axios from "axios";
import { apiDomain } from "../../config";
export default {
  components: {
    VueperSlides,
    VueperSlide,
  },
  data() {
    return {
      apiDomain: "https://etnafesapi20212018.etnafes.com",
    };
  },
};
</script>