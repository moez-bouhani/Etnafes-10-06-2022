<template>
  <div>Supprimée des packs "J'aime ce contenu".</div>
</template>

<script>
export default {
  name: "notification-template"
};
</script>
