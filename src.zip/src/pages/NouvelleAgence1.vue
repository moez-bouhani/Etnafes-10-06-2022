<template>
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <card>
          <form @submit.prevent="createAgence">
            <card style="border:solid 1px #7a7979;padding:15px">
              <div class="row">
                <div class="col-md-4 pr-md-1 text-left">
                  <base-input
                    v-if="agencesln==0"
                    label="Nom agence"
                    placeholder="Nom agence"
                    v-model="agence.nom_agence"
                  ></base-input>

                  <base-input
                    label="Nom agence"
                    placeholder="Nom agence"
                    disabled
                    v-if="agencesln>0"
                    :value="agencesln>0 ? agences.data[0].nom_agence : ''"
                  ></base-input>
                  <p v-if="validationErrors.nom_agence" style="padding-bottom:5px;color:red">
                    <span class="alert-link">** {{ validationErrors.nom_agence[0] }}</span>
                  </p>
                </div>
                <div class="col-md-4 px-md-1 text-left">
                  <base-input
                    required
                    type="text"
                    label="Adresse"
                    placeholder="Adresse"
                    v-model="agence.adresse"
                  ></base-input>
                  <p v-if="validationErrors.adresse" style="padding-bottom:5px;color:red">
                    <span class="alert-link">** {{ validationErrors.adresse[0] }}</span>
                  </p>
                </div>

                <div class="col-md-4 pl-md-1 text-left">
                  <base-input
                    type="text"
                    label="Telephone"
                    placeholder="Telephone"
                    v-model="agence.telephone"
                  ></base-input>
                  <p v-if="validationErrors.telephone" style="padding-bottom:5px;color:red">
                    <span class="alert-link">** {{ validationErrors.telephone[0] }}</span>
                  </p>
                </div>
              </div>

              <div class="row">
                <div class="col-md-4 pr-md-1 text-left">
                  <base-input placeholder="Email" label="Email" v-model="agence.email" type="email"></base-input>
                  <p v-if="validationErrors.email" style="padding-bottom:5px;color:red">
                    <span class="alert-link">** {{ validationErrors.email[0] }}</span>
                  </p>
                </div>
                <div class="col-md-4 px-md-1 text-left">
                  <label>Ville</label>
                  <select class="form-control" v-model="agence.ville_id" name="ville" required>
                    <option
                      v-for="ville in villes"
                      v-bind:key="ville.id"
                      v-bind:value="ville.id"
                    >{{ville.nom}}</option>
                  </select>
                  <p v-if="validationErrors.ville_id" style="padding-bottom:5px;color:red">
                    <span class="alert-link">** {{ validationErrors.ville_id[0] }}</span>
                  </p>
                </div>

                <div class="col-md-4 px-md-1 text-left">
                  <label>Logo</label>
                  <br />
                  <input
                    aria-label="label"
                    required
                    name="logo"
                    type="file"
                    @change="agencePhoto"
                    class="input-file"
                    accept="image/x-png, image/gif, image/jpeg"
                  />
                </div>
              </div>

              <!-- <div class="row">
                <div class="col-md-12 pr-md-1 text-left">
                  <label>Logo</label>
                  <br />
                  <input
                    required
                    name="logo"
                    type="file"
                    @change="agencePhoto"
                    class="input-file"
                    accept="image/x-png, image/gif, image/jpeg"
                  />
                </div>
              </div>-->

              <br />
            </card>
            <br />
            <div>
              <div class="row">
                <button
                  class="btn btn-success"
                  type="submit"
                  fill
                  style="margin-left:10px;border-radius: 18px 0px 18px 0px;"
                >Enregistrer</button>
              </div>
            </div>
          </form>
        </card>
      </div>
    </div>
  </div>
</template>
<script>
import Vue from "vue";
import { Card, BaseInput } from "@/components/index";
import BaseButton from "@/components/BaseButton";
import { apiDomain } from "../config";
export default {
  components: {
    Card,
    BaseInput,
    BaseButton
  },
  data() {
    return {
      agencesln: "",
      agences: [],
      adagence: [],
      validationErrors: "",
      ville_id: "",
      ville: {},
      villes: {},
      agence: {
        adagence_id: this.$store.state.propagence[0].id
      }
    };
  },

  computed: {
    propagence() {
      return this.$store.getters.get_propagence;
    }
  },
  created() {
    this.fetchVilles();
    this.fetchAdagence(this.$store.state.propagence[0].id);
    this.fetchAgences(this.$store.state.propagence[0].id);
  },
  methods: {
    fetchAgences(id) {
      fetch(`${apiDomain}/api/agences/admin/${id}`)
        .then(res => res.json())
        .then(res => {
          this.agences = res.agences;
          this.agencesln = res.agencesln;
        })
        .catch(err => console.log(err));
    },
    fetchAdagence(id) {
      fetch(`${apiDomain}/api/adagence/${id}`)
        .then(res => res.json())
        .then(res => {
          this.adagence = res;
        })
        .catch(err => console.log(err));
    },
    fetchVilles() {
      axios
        .get(`${apiDomain}/api/allvillesTun`)
        .then(({ data }) => (this.villes = data.villes));
    },

    agencePhoto: function(event) {
      var input = event.target;
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        var vm = this;
        reader.onload = function(e) {
          vm.agence.logo = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
      }
      console.log(input.files[0]);
    },

    createAgence(e) {
      var formData = new FormData(e.target);
      if (this.agencesln > 0) {
        formData.append("nom_agence", this.agences.data[0].nom_agence);
      } else {
        formData.append("nom_agence", this.agence.nom_agence);
      }
      formData.append("email", this.agence.email);
      formData.append("telephone", this.agence.telephone);
      formData.append("adresse", this.agence.adresse);
      formData.append("ville_id", this.agence.ville_id);
      formData.append("adagence_id", this.agence.adagence_id);
      axios
        .post(`${apiDomain}/api/create/agence`, formData, {
          headers: {
            "Content-Type": "multipart/form-data"
          }
        })
        .then(res => {
          if (res.status == 200) {
            this.$fire({
              text: "votre agence a été ajouté avec succès",
              type: "success",
              timer: 90000
            }).then(r => {
              window.location.reload();
            });
            /* this.$noty.success("Prestataire de Services Ajoutée avec succés.");
            this.$router.push({ name: "Agences" }); */
          }
        })
        .catch(error => {
          if (error.response && error.response.status == 400) {
            this.validationErrors = error.response.data;
          }
        });
      fetch(
        `${apiDomain}/api/adagence-validate/${this.$store.state.propagence[0].id}`,
        {
          method: "put",
          body: JSON.stringify(this.adagence),
          headers: {
            "content-type": "application/json"
          }
        }
      );
    }
  }
};
</script>

