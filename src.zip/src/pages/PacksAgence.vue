<template>
  <div class="content">
    <!--  <router-link :to="{name:'nouveau_pack_agence'}">
      <button
        type="button"
        class="btn btn-outline-success mt-3 btnajout"
        style="color:#fff;margin-bottom:20px;border-radius: 18px 0px 18px 0px;"
      >
        <i class="fa fa-plus"></i>
        &nbsp;&nbsp;Nouveau Pack
      </button>
    </router-link>-->
    <div class="row">
      <div class="col-md-12">
        <div>
          <div class="row" v-show="packs.data.length!=0">
            <div class="col-md-12">
              <input
                aria-label="label"
                type="text"
                style="border:1px solid #ebebeb;width:100%;height:30px;margin-bottom:10px"
                v-model="search"
                placeholder="Chercher un pack : exemple par date 2020-10-01"
              />
            </div>
          </div>

          <div
            class="table-responsive text-left"
            v-show="filteredPacks.length>0"
            style="border:solid 1px #9b9b9b;"
          >
            <table class="table table-hover">
              <thead>
                <tr>
                  <th scope="col" style="text-transform: none;">Titre</th>
                  <th scope="col" style="text-transform: none;">Date début</th>
                  <th scope="col" style="text-transform: none;">Date fin</th>
                  <th scope="col" style="text-transform: none;">Prix fix</th>
                  <th scope="col" style="text-transform: none;">Statut</th>

                  <th scope="col" style="text-transform: none;">
                    <center>Actions</center>
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr
                  :style="[pack.readv==0 ? {'background-color': '#e7f1fd'} : {'background-color': 'none'}]"
                  v-for="pack in filteredPacks"
                  v-bind:key="pack.id"
                >
                  <td>{{pack.titre}}</td>
                  <td>{{pack.date_deb}}</td>
                  <td>{{pack.date_fin}}</td>
                  <td>{{pack.prix_fix}} dt</td>
                  <td>
                    <span v-if="pack.valide==0">Non valide</span>

                    <span v-if="pack.valide==1">Valide</span>
                  </td>

                  <td>
                    <center>
                      <router-link :to="{name:'show_pack_agence', params: { id:pack.id} }">
                        <i class="tim-icons icon-send" title="Cosulter le pack"></i>
                      </router-link>&nbsp;
                      <router-link
                        :to="{name:'edit_pack_agence', params: { id:pack.id} }"
                        v-show="pack.reservation.length==0"
                      >
                        <i
                          class="tim-icons icon-pencil"
                          style="color:#62b062"
                          title="Modifier le pack"
                        ></i>
                      </router-link>&nbsp;
                      <i
                        v-show="pack.reservation.length>0"
                        class="tim-icons icon-pencil"
                        style="color:#62b062;opacity:0.5"
                        title="Modification désactivée"
                      ></i>
                      <!-- <i
                        v-show="pack.reservation.length==0"
                        style="color: #fd5d93;"
                        class="tim-icons icon-simple-remove"
                        title="Delete pack"
                        @click="deletePack(pack.id)"
                      ></i>

                      <i
                        v-else
                        style="color: #fd5d93;opacity:0.5"
                        class="tim-icons icon-simple-remove"
                        title="Delete disabled"
                      ></i>-->
                    </center>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div v-show="packs.data.length==0 && filteredPacks.length==0 ">
            <p>Vous n'avez aucun pack jusqu'au moment.</p>
          </div>

          <div v-show="filteredPacks.length==0 && packs.data.length>0">
            <p>Votre recherche ne correspond à aucun pack.</p>
          </div>

          <pagination
            v-show="filteredPacks.length!=0"
            :data="packs"
            :limit="4"
            @pagination-change-page="fetchPacksPaginate"
          ></pagination>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import BaseTable from "@/components/BaseTable";
import { Card } from "@/components/index";
import { apiDomain } from "../config";
const tableColumns = ["Titre", "Date_deb", "Date_fin", "Prix_fix"];
// const tableData = [this.packs];
export default {
  components: {
    Card,
    BaseTable
  },
  data() {
    return {
      packsln: "",
      columns: ["id", "name", "job", "since", "salary", "actions"],
      search: "",
      table1: {
        title: "Simple Table",
        columns: [...tableColumns]
        // data: [...this.packs]
      },
      packs: { data: [] }
    };
  },

  computed: {
    filteredPacks: function() {
      if (Array.isArray(this.packs.data)) {
        return this.packs.data.filter(pack => {
          return (
            pack.titre.match(this.search) ||
            pack.date_deb.match(this.search) ||
            pack.date_fin.match(this.search) ||
            pack.description.match(this.search)
          );
        });
      }
    },
    loggedIn() {
      return this.$store.getters.get_loggedIn;
    },
    propagence() {
      return this.$store.getters.get_propagence;
    },

    user() {
      return this.$store.getters.get_user;
    }
  },
  created() {
    this.fetchPacks(this.$store.state.propagence[0].id);
  },
  methods: {
    deletePack(id) {
      if (confirm("Are You Sure?")) {
        fetch(`${apiDomain}/api/pack/delete/${id}`, {
          method: "delete"
        })
          .then(res => res.json())
          .then(data => {
            alert("Pack Supprimée");
            window.location.reload();
          })
          .catch(err => console.log(err));
      }
    },

    fetchPacksPaginate(page) {
      if (typeof page === "undefined") {
        page = 1;
      }
      let vm = this;
      fetch(
        `${apiDomain}/api/agence/packs/${this.$store.state.propagence[0].id}?page=` +
          page
      )
        .then(res => res.json())
        .then(data => {
          this.packs = data.packs;
          this.packss = data.packs.data;
        })
        .catch(err => console.log(err));
    },
    fetchPacks(id) {
      fetch(`${apiDomain}/api/agence/packs/${id}`)
        .then(res => res.json())
        .then(res => {
          this.packs = res.packs;
          this.packsln = res.packsln;
        })
        .catch(err => console.log(err));
    }
  }
};
</script>

<style>
/* .card .card-body {
  padding: 3px;
} */
</style>
