<template>
  <div>
    <TopNavbarHome />

    <div
      class="container"
      style="margin-bottom: 30px; margin-top: 40px; border: solid 1px #afaeae"
    >
      <b-modal id="modal-paymee">
        <iframe
          style="border: 1px solid #c4252c; width: 100%"
          height="500"
          width="100%"
          id="inlineFrameExample"
          :src="url_frame"
        ></iframe>
      </b-modal>
      <div class="row">
        <div class="col-md-12">
          <!--Card content-->
          <div class="card-body">
            <!-- Form -->
            <form name>
              <!-- Heading -->
              <h4
                class="dark-grey-text text-center"
                style="margin-top: 25px; font-family: 'Poppins', sans-serif"
              >
                <strong
                  style="
                    color: #333;
                    font-family: 'Poppins', sans-serif;
                    letter-spacing: 1px;
                    font-size: 20px;
                  "
                  >Modifier votre recherche</strong
                >
              </h4>

              <div class="row" style="margin-top: 25px">
                <div class="col-sm-12 col-xs-3">
                  <div class="row">
                    <div class="col-md-1">
                      <div>
                        <label
                          style="
                            color: #000;
                            font-size: 13px;
                            font-weight: bold;
                          "
                          >Arrivée</label
                        >
                      </div>
                    </div>

                    <div class="col-md-4">
                      <div class="form-group">
                        <b-form-datepicker
                          style="height: auto !important"
                          autofocus
                          format="dd-mm-yyyy"
                          placeholder="Ajouter une date"
                          :min="new Date()"
                          @input="test"
                          :date-disabled-fn="dateDisabled"
                          locale="en"
                          v-model="du"
                        ></b-form-datepicker>
                      </div>
                    </div>
                    <div class="col-md-1">
                      <div>
                        <label
                          style="
                            color: #000;
                            font-size: 13px;
                            font-weight: bold;
                          "
                          >Départ</label
                        >
                      </div>
                    </div>

                    <div class="col-md-4">
                      <div class="form-group" v-if="seendep == false">
                        <b-form-datepicker
                          disabled
                          placeholder="Ajouter une date"
                          :min="new Date(next)"
                          :date-disabled-fn="dateDisabled"
                          locale="en"
                          v-model="au"
                          @input="calculInterval"
                        ></b-form-datepicker>
                      </div>

                      <div class="form-group" v-if="seendep == true">
                        <b-form-datepicker
                          placeholder="Ajouter une date"
                          :min="new Date(next)"
                          :date-disabled-fn="dateDisabledDep"
                          locale="en"
                          v-model="au"
                          @input="calculInterval"
                        ></b-form-datepicker>
                      </div>
                    </div>
                  </div>

                  <h6
                    v-if="nuit == true"
                    style="line-height: 35px; color: #ed0000"
                  >
                    NB: La Réservation est pour deux nuits au minimum
                  </h6>

                  <div class="row">
                    <div class="col-md-1">
                      <div>
                        <label
                          style="
                            color: #000;
                            font-size: 13px;
                            font-weight: bold;
                          "
                          >Adultes</label
                        >
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <input
                          aria-label="label"
                          autofocus
                          min="1"
                          type="number"
                          name="nb_adulte"
                          v-on:input="updateNbAdulte"
                          required
                          v-model="nb_adulte"
                        />
                      </div>
                    </div>
                    <div class="col-md-1">
                      <div>
                        <label
                          style="
                            color: #000;
                            font-size: 13px;
                            font-weight: bold;
                          "
                          >Enfants</label
                        >
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <input
                          aria-label="label"
                          :min="agestab != undefined ? agestab.length : 0"
                          class="personalise22"
                          v-on:input="updateNbEnfant"
                          type="number"
                          name="nb_enfant"
                          required
                          v-model="nb_enfant"
                        />
                      </div>
                    </div>
                    <div class="col-md-2" v-if="nb_enfant > 0">
                      <div>
                        <label
                          style="
                            color: #000;
                            font-size: 13px;
                            font-weight: bold;
                          "
                          >Age Enfants:</label
                        >
                      </div>
                    </div>

                    <div class="col-md-2">
                      <!-- <div
                        class="form-group"
                        v-for="(age,index) in Number(this.$store.state.nb_enfant)"
                        :key="index"
                      >-->

                      <div
                        class="form-group"
                        v-for="(age, index) in Number(this.nb_enfant)"
                        :key="index"
                      >
                        <select
                          class="form-control"
                          v-model="agestab[index]"
                          @change="addNewAge"
                          required
                        >
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="4">4</option>
                          <option value="5">5</option>
                          <option value="6">6</option>
                          <option value="7">7</option>
                          <option value="8">8</option>
                          <option value="9">9</option>
                          <option value="10">10</option>
                          <option value="11">11</option>
                          <option value="12">12</option>
                          <option value="13">13</option>
                          <option value="14">14</option>
                          <option value="15">15</option>
                        </select>
                        <img
                          style="margin-top: -20px"
                          src="/minus-etnafes.png"
                          v-on:click="removeAge(index)"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <h3 style="color: #333" v-if="nb_adulte != null && nb_enfant > 0">
                Total:
                {{
                  (Number(nb_adulte) * hebergement.prix_adulte +
                    calculPrix[0]) *
                  (arr.length - 1)
                }}dt
              </h3>

              <h3 style="color: #333" v-if="nb_enfant == 0">
                Total:
                {{
                  Number(nb_adulte) *
                  hebergement.prix_adulte *
                  (arr.length - 1)
                }}dt
              </h3>
            </form>
            <!-- Form -->
          </div>
        </div>
      </div>
    </div>

    <div
      class="container"
      style="margin-bottom: 30px; margin-top: 40px; border: solid 1px #afaeae"
    >
      <div class="row" style="margin-top: 40px">
        <div class="col-sm-12 col-xs-3">
          <h4
            class="dark-grey-text"
            style="line-height: 60px; font-family: 'Open Sans', sans-serif"
          >
            <strong style="font-family: 'Indie Flower', cursive; color: #000"
              >Demande de réservation:</strong
            >
            &nbsp;
            <strong
              style="font-family: 'Indie Flower', cursive; color: #ff931f"
              >{{ hebergement.nom }}</strong
            >
          </h4>
          <hr />
        </div>
      </div>

      <!-- v-on:submit.prevent="addReservation()" -->
      <div class="row">
        <div class="col-md-6">
          <span style="font-weight: bold; line-height: 30px">Dates</span>
          <br />
          {{ du }} / {{ au }} ({{ arr.length - 1 }} nuits)
          <br />
          <br />
          <br />
          <span style="font-weight: bold; line-height: 30px">Voyageurs</span>
          <br />
          {{ Number(nb_adulte) + Number(nb_enfant) }} voyageurs ({{
            nb_adulte
          }}
          adulte(s) et {{ nb_enfant }} enfant(s))
        </div>
        <div class="col-md-6">
          <span style="font-weight: bold; line-height: 30px"
            >Choisissez le moyen de paiement</span
          >
          <br />
          <div class="row">
            <div class="col-md-11">
              <!-- <input
                        aria-label="label"
                        type="radio"
                        v-bind:key="agence_id"
                        v-model="agence_id"
                        v-bind:value="agence.id"
                        name="agence_id"
                        @input="updateAgence"
                      />-->
              <input
                v-model="type_paiement"
                value="offline"
                aria-label="label"
                type="radio"
              />
              <span>&nbsp;Offline</span>
            </div>
          </div>
          <br />
          <div class="row">
            <div class="col-md-11">
              <!-- <input
                        aria-label="label"
                        type="radio"
                        v-bind:key="agence_id"
                        v-model="agence_id"
                        v-bind:value="agence.id"
                        name="agence_id"
                        @input="updateAgence"
                      />-->
              <input
                v-model="type_paiement"
                value="en ligne"
                aria-label="label"
                type="radio"
              />
              <img src="/paiment-etnafes-tn.png" />
            </div>
          </div>

          <!--  <div
              v-for="paiement in paiements"
              :key="paiement.id"
              style="padding:5px;margin-bottom:20px"
            >
              <input
                aria-label="label"
                type="radio"
                v-bind:key="paiement.id"
                v-model="paiement_id"
                v-bind:value="paiement.id"
                name="paiement_id"
              />
              {{paiement.type}}
            </div> -->

          <!--  <div class="alert alert-danger" v-if="validationErrors.paiement_id">
              <span>{{ validationErrors.paiement_id[0] }}</span>
            </div> -->
        </div>
      </div>
      <br />
      <!-- {{au>du}} -->
      <button
        @click="stepOnePayemee()"
        v-b-modal.modal-paymee
        v-if="
          type_paiement != '' && agestab.length == nb_enfant && au > du == true
        "
        class="btn btn-success"
        type="submit"
        fill
        style="margin-left: 10px"
      >
        Demande de réservation
      </button>
    </div>

    <Footer></Footer>
  </div>
</template>

<style>
@media (min-width: 1200px) {
  .container {
    max-width: 1420px;
  }
}
</style>

<script>
import moment from "moment";
import Datepicker from "vuejs-datepicker";
import MapMarker from "../components/MapMarker";
import MapInfoWindow from "../components/MapInfoWindow";
import axios from "axios";
import { VueperSlides, VueperSlide } from "vueperslides";
import "vueperslides/dist/vueperslides.css";
import TopNavbarHome from "./Layout/TopNavbarHome.vue";
import Footer from "./Layout/Footer.vue";
import { apiDomain } from "../config";
import InfoDepanneur from "./InfoDepanneur.vue";
import Vue from "vue";
export default {
  components: {
    TopNavbarHome,
    Footer,
    VueperSlides,
    VueperSlide,
    "info-content": InfoDepanneur,
    MapMarker,
    MapInfoWindow,
    Datepicker,
  },
  data() {
    return {
      type_paiement: "",

      url_frame: "",
      code_compt: "13639", //ligne
      //code_compt: "1915",

      note: "Etnafes " + "#" + Math.floor(Math.random() * 40000),

      token_client: "",
      prix_total: "",
      agestab: this.$route.query.ages ? this.$route.query.ages : [],

      nuit: false,
      datedes: "",
      pays: {},
      pays_id: "",
      validationErrors: "",
      nom: "",
      email: this.$store.state.user.email,
      telephone: "",
      password: "",
      error: "",
      civilité: "",
      ages: [],
      seen: false,
      seendep: false,

      arrd: [],

      des: {},
      dateFormat: "dd-MM-yyyy",

      dates: {},
      interval: {},
      paiement_id: "",
      isHidden: true,
      index: null,
      infoContent: "",
      infoWindowPos: {
        lat: 0,
        lng: 0,
      },

      nb_adulte: this.$route.query.nb_adulte,
      nb_enfant: this.$route.query.nb_enfant,
      arr: this.$route.query.arr,

      du: this.$route.query.du,
      au: this.$route.query.au,
      next: "",

      nb_nuit: "",

      infoWinOpen: false,
      currentMidx: null,
      infoOptions: {
        pixelOffset: {
          width: 0,
          height: -35,
        },
      },
      map: null,
      center: { lat: 36.81897, lng: 10.16579 },
      markers: [],
      InfoDepanneur: [],
      markersh: [],

      places: [],
      currentPlace: null,
      // packs:[],
      entercode: false,
      nb_enfant4: 0,
      nb_enfant15: 0,

      apiDomain: "https://etnafesapi20212018.etnafes.com",
      packsvedette: [],
      hebergements: {},
      hebergement: {},
      client: {},
      paiements: {},
      pack: {
        id: "",
        nom: "",
        du: "",
        description: "",
        au: "",
        type: "",
        ville_id: "",
      },
      slide: 0,
      sliding: null,
    };
  },

  created() {
    this.fetchHebergement(this.$route.params.id);

    this.fetchPaiements();
    this.fetchPays();

    Bus.$on("markers_fetched", (data) => {
      this.markersh = data.markersh;
      if (this.markersh.length > 0) {
        this.center = data.markersh[0].position;
      }
      console.log("event data", data);
    });

    Bus.$on("marker_result_clicked", (index) => {
      let targetMarker = this.markersh[index];
      this.center = targetMarker.position;
      this.toggleInfoWindow(targetMarker, index);
    });
  },
  computed: {
    formatterDate() {
      const arr = this.arr;
      const output = arr.map((str) => {
        /* Split date string into sub string parts */
        var [year, month, date] = str.split("-");
        /*  var mm=("0" + month).slice(-2);
  var dd=("0" + date+1).slice(-2); */
        // var dd = date< 10 ? '0' +date: ''+date;

        if (month < 10) {
          month = "0" + month;
        }

        if (year < 10) {
          year = "0" + year;
        }

        /* if (date < 10) 
        date = '0' + date; */

        /* Compose a new date from sub string parts of desired format */
        return `${date}-${month}-${year}`;
        // return `${year}-${month}-${date}`;
      });
      return output;
    },

    /*  for(var i=0;i<arrdates.length;i++)
      {
        var d = new Date(arrdates[i]);
        month = '' + (d.getMonth() + 1);
        day = '' + d.getDate();
        year = d.getFullYear();
        if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;
         const interval = [year, month, day].join('-');
         result.push(interval);
      }
return result; */

    calculage() {
      // const agestab = this.agesForm;
      const agestab = this.agestab;

      var result = [];
      this.nbenfant4 = 0;
      this.nbenfant15 = 0;
      if (this.ages != 0) {
        for (var k = 0; k < agestab.length; k++) {
          if (agestab[k] <= 4) {
            this.nbenfant4 = parseInt(this.nbenfant4) + 1;
          }
          if (agestab[k] > 4) {
            this.nbenfant15 = parseInt(this.nbenfant15) + 1;
          }
        }
      }
      return [this.nbenfant4, this.nbenfant15];
    },
    agesForm() {
      const ages = this.agestab;
      var result = [];
      if (ages.length != 0) {
        for (var i = 0; i < ages.length - 1; i++) {
          result.push(ages[i]);
        }
      }
      return result;
    },
    calculPrix() {
      const hebergement = this.hebergement;
      // const agestab = this.agesForm;
      const agestab = this.agestab;

      var result = [];
      var somme = null;

      var sommeprixenfant4 = 0;
      var sommeprixenfant15 = 0;
      for (var i = 0; i < agestab.length; i++) {
        if (agestab[i] <= 4) {
          sommeprixenfant4 += hebergement.prix_enfant;
        }
        if (agestab[i] > 4) {
          sommeprixenfant15 += hebergement.prix_enfant15;
        }
      }
      somme += sommeprixenfant4 + sommeprixenfant15;
      result.push(somme);

      return result;
    },
    nb_adulte_Moez() {
      return this.nb_adulte;
    },

    nb_enfant_Moez() {
      return this.enfants;
    },
    nbr_places_total_Moez() {
      return Number(this.nb_adulte_Moez) + Number(this.enfants);
    },
    nbr_places_dispo_Moez() {
      return (
        Number(this.hebergement.nbr_place_dispo) -
        Number(this.nbr_places_total_Moez)
      );
    },

    sommeMoez() {
      return (
        (this.nb_adulte * this.hebergement.prix_adulte + this.calculPrix[0]) *
        (this.arr.length - 1)
      );
    },
    loggedIn() {
      return this.$store.getters.get_loggedIn;
    },

    user() {
      return this.$store.getters.get_user;
    },

    adultes: {
      get() {
        return this.$store.state.nb_adulte;
      },
      set(value) {
        this.$store.commit("updateNbAdulte", value);
      },
    },
    enfants: {
      get() {
        return this.$store.state.nb_enfant;
      },
      set(value) {
        this.$store.commit("updateNbEnfant", value);
      },
    },
    beforeShowDay() {
      var dispo = this.hebergement.disponibilite;
      // var des = [];
      if (dispo) {
        var des = dispo.split(",").sort();
      }
      return des;
    },
  },

  mounted() {
    //  this.fechStep3();

    window.addEventListener(
      "message",
      function (event) {
        if (event.data.event_id === "paymee.complete") {
          // window.location.replace("https://etnafes.com/suivant_logement");
          window.location.replace("https://etnafes.com/suivant_logement");
        }
      },
      false
    );
  },
  methods: {
    stepOnePayemee() {
      let formData = new FormData();

      formData.append("vendor", this.code_compt);
      formData.append("amount", this.sommeMoez);
      formData.append("note", this.note);

      axios
        .post(`https://app.paymee.tn/api/v1/payments/create`, formData, {
          body: JSON.stringify(this.annonce),
          headers: {
            "Content-Type": "application/json",

            Authorization: "Token ed6b25dc0ae4a9195b30be5f9e4f19a1383eb83b", // en ligen
            // Authorization: "Token a6408a6150213d091a55669461fc9fc1b34d2192",
          },
        })

        .then((res) => {
          this.token_client = res.data.data.token;
          this.url_frame = `https://app.paymee.tn/gateway/${this.token_client}`; //step2

          localStorage.setItem("token_client", this.token_client);
          //query
          localStorage.setItem("logement_id", this.$route.params.id);
          localStorage.setItem("prix_logement", this.sommeMoez);

          localStorage.setItem("du", this.$route.query.du);
          localStorage.setItem("au", this.$route.query.au);
          localStorage.setItem("nom_hebergement", this.hebergement.nom);
          localStorage.setItem("arr", this.formatterDate);

          localStorage.setItem("nb_enfant4", this.calculage[0]);
          localStorage.setItem("nb_enfant15", this.calculage[1]);

          localStorage.setItem("nb_enfants", this.nb_enfant_Moez);
          localStorage.setItem("nb_adultes", this.nb_adulte_Moez);

          localStorage.setItem(
            "nbr_places_dispo_Moez",
            this.nbr_places_dispo_Moez
          );
          localStorage.setItem(
            "nbr_places_total_Moez",
            this.nbr_places_total_Moez
          );

          /* 
          localStorage.setItem(
            "nb_enfant",
            Number(localStorage.setItem("nb_enfant4", this.calculage[0])) +
              Number(localStorage.setItem("nb_enfant15", this.calculage[1]))
          ); */
        })

        .catch((error) => {
          console.log(error.response.data);
        });
    },
    removeAge: function (index) {
      Vue.delete(this.agestab, index);
      this.nb_enfant = this.nb_enfant - 1;
    },
    onChange(v) {
      console.log("onChange ", v);
    },
    onComplete(v) {
      console.log("onComplete ", v);
    },
    addClient() {
      this.entercode = false;
      axios
        .post(`${apiDomain}/api/register/client`, {
          nom: this.client.nom,
          prenom: this.client.prenom,
          telephone: this.client.telephone,
          email: this.client.email,
          civilité: this.civilité,
          password: this.client.password,

          gouvernorat: this.gouvernorat,
          agence_id: this.agence_id,
          headers: {
            "content-type": "application/json",
          },
        })
        .then((response) => {
          if (response.status == 201) {
            this.entercode = true;
            // alert("Client Ajoutée");
            // console.log("success");
          }
        })
        .catch((error) => {
          if (error.response && error.response.status == 400) {
            this.validationErrors = error.response.data;
          }
        });
    },
    addReservation() {
      if (this.calculPrix.length != 0) {
        this.prix_total =
          (this.nb_adulte * this.hebergement.prix_adulte + this.calculPrix[0]) *
          (this.arr.length - 1);
      } else if (this.calculPrix.length == 0) {
        this.prix_total =
          this.nb_adulte * this.hebergement.prix_adulte * (this.arr.length - 1);
      }

      axios
        .post(`${apiDomain}/api/reservation/hebergement`, {
          du: this.du,
          au: this.au,
          paye: 0,
          read: 0,

          hebergement_id: this.$route.params.id,
          client_id: this.$store.state.user.id,
          prix_remise: this.prix_remise,
          nbr_place: Number(this.nb_adulte) + Number(this.nb_enfant),
          prix_total: this.prix_total,
          nb_adulte: this.nb_adulte,
          nb_enfant4: this.calculage[0],
          nb_enfant15: this.calculage[1],

          headers: {
            "content-type": "application/json",
          },
        })
        .then((response) => {
          if (response.status == 200) {
            alert("réservation avec succés");
          }
        })
        .catch((error) => {
          if (error.response && error.response.status == 400) {
            this.validationErrors = error.response.data;
          }
        });

      axios.post(`${apiDomain}/api/reservation/mail`, {
        mail: this.email,
      });

      axios.post(
        `${apiDomain}/api/hebergement/place/${this.$route.params.id}`,
        {
          nbr_place_dispo:
            this.hebergement.nbr_place_dispo -
            (Number(this.nb_adulte) + Number(this.nb_enfant)),
        }
      );
    },
    test() {
      const interval = this.beforeShowDay;
      var du = new Date(this.du);
      var month = du.getUTCMonth() + 1;
      var d = du.getUTCDate() + 1;
      var day = ("0" + d).slice(-2);
      var year = du.getUTCFullYear();

      //var newdate = day + "-" + month + "-" + year;

      var nextDay = du.getUTCDate() + 1;
      var nextDD = ("0" + nextDay).slice(-2);
      var nextDate = year + "-" + month + "-" + nextDD;
      /* console.log(this.du);
      console.log(nextDate); */
      this.next = nextDate;
      var result = [];
      var somme = null;
      if (interval.includes(this.next)) {
        this.seendep = false;
        this.nuit = true;
      } else {
        this.seendep = true;
        this.nuit = false;
        if (this.next != interval[i]) {
          for (var i = 0; i < interval.length; i++) {
            if (this.next < interval[i]) {
              this.datedes = interval[i];
              break;
            }
          }
        }
      }
    },
    testArrivée() {
      alert("rrded vgezfezf hzeftez hzefeg");
    },
    fetchPays() {
      axios.get(`${apiDomain}/api/pays`).then(({ data }) => (this.pays = data));
    },
    addNewAge: function () {
      this.ages.push(Vue.util.extend({}, this.age));
    },

    updateNbAdulte(e) {
      this.$store.commit("updateNbAdulte", e.target.value);
    },

    updateNbEnfant(e) {
      this.seen = true;
      this.$store.commit("updateNbEnfant", e.target.value);
    },
    dateDisabled(dmy, date) {
      if (this.beforeShowDay.length != 0) {
        const interval = this.beforeShowDay;

        var month = date.getUTCMonth() + 1; //months from 1-12
        var d = date.getUTCDate() + 1;
        var day = ("0" + d).slice(-2);
        var year = date.getUTCFullYear();

        var newdate = year + "-" + month + "-" + day;

        for (var i = 0; i < interval.length; i++) {
          if (newdate == interval[i]) {
            return true;
          }
        }
      }
    },

    dateDisabledDep(dmy, date) {
      if (this.beforeShowDay.length != 0) {
        const interval = this.beforeShowDay;
        var month = date.getUTCMonth() + 1; //months from 1-12
        var d = date.getUTCDate() + 1;
        var day = ("0" + d).slice(-2);
        var year = date.getUTCFullYear();
        var newdate = year + "-" + month + "-" + day;

        for (var i = 0; i < interval.length; i++) {
          if (newdate == interval[i]) {
            return true;
          }
        }
        if (this.datedes != "") {
          if (newdate >= this.datedes) {
            return true;
          }
        }
      }
    },

    customFormatter(date) {
      // return moment(date).format("MMMM Do YYYY, h:mm:ss a");
      return (this.interval = moment(date).format("YYYY-m-d"));
    },

    calculIn(du, date) {
      if (this.beforeShowDay.length != 0) {
        const interval = this.beforeShowDay;

        var month = date.getUTCMonth() + 1; //months from 1-12
        var d = date.getUTCDate() + 1;
        var day = ("0" + d).slice(-2);
        var year = date.getUTCFullYear();

        var newdate = day + "-" + month + "-" + year;
        // var du = new Date(this.du);
        var du = new Date(this.du);

        var nextDay = du.getUTCDate() + 1;
        var nextDate = nextDay + "-" + month + "-" + year;

        console.log(nextDate);
        for (var i = 0; i < interval.length; i++) {
          if (du != interval[i] && nextDate == interval[i]) {
            return true;
          }
        }
      }
    },

    calculInterval(du, au) {
      var du = this.du,
        au = this.au;

      var arr = [],
        dt = new Date(du);

      while (dt <= new Date(au)) {
        arr.push(new Date(dt));
        dt.setDate(dt.getDate() + 1);
      }
      for (var l = 0; l < arr.length; l++) {
        var month = arr[l].getUTCMonth() + 1; //months from 1-12
        var day = arr[l].getUTCDate();
        var year = arr[l].getUTCFullYear();
        arr[l] = day + "-" + month + "-" + year;
        //console.log(arr[l]);
      }

      const before = this.beforeShowDay;
      for (var j = 0; j < arr.length; j++) {
        for (var k = 0; k < before.length; k++) {
          if (arr[j] == before[k]) {
            alert(
              "La réservation est pour deux nuits successifs au minimum la date " +
                arr[j] +
                " est déja réservée"
            );
            this.au = "";
          }
        }
      }
      return (this.arr = arr);
    },

    initialiser() {
      (this.du = ""), (this.au = "");
    },

    fetchPaiements() {
      axios
        .get(`${apiDomain}/api/paiements`)
        .then(({ data }) => (this.paiements = data));
    },
    hasHistory() {
      return window.history.length > 2;
    },
    toggleInfoWindow(marker, idx) {
      this.infoWindowPos = marker.position;
      this.InfoDepanneur = marker.position;

      //check if its the same marker that was selected if yes toggle
      if (this.currentMidx == idx) {
        this.infoWinOpen = !this.infoWinOpen;
      }
      //if different marker set infowindow to open and reset current marker index
      else {
        this.infoWinOpen = true;
        this.currentMidx = idx;
      }
    },

    onSlideStart(slide) {
      this.sliding = true;
    },
    onSlideEnd(slide) {
      this.sliding = false;
    },
    fetchPacksVedette(ville_id) {
      axios
        .get(`${apiDomain}/api/packs/reservation/${ville_id}`)
        .then(({ data }) => (this.packsvedette = data.pack));
    },

    fetchHebergement(id) {
      fetch(`${apiDomain}/api/hebergement/${id}`)
        .then((res) => res.json())
        .then((res) => {
          this.hebergement = res.hebergement;
          this.imagehebergements = res.hebergement.images_hebergement;
          this.interval = res.interval;
        })
        .catch((err) => console.log(err));
    },
    fetchPacks(id) {
      axios
        .get(`${apiDomain}/api/packs/${id}`)
        .then(({ data }) => (this.pack = data.packdetail));
    },
  },
};
</script>

<style>
#modal-paymee .modal-content {
  width: 69% !important;
}
</style>