
<template>
  <div>
    Hello Moez
    <Vr360 :imgSrc="url" />
    <!-- <Tour :scenes="scenes"></Tour> -->

    <!--    <div class="demo-loading" v-show="loading"></div> -->
  </div>
</template>

<script>
import { Tour } from "vuejs-vr";
import Vr360 from "vue-360vr";

export default {
  components: {
    Tour,

    Vr360
  },
  data() {
    return {
      url: "ETNAFES-dar-lela-Hbiba.jpg",
      scenes: [
        {
          key: "M4wOy2s",
          panorama: {
            source: "https://etnafes.com/images/foret-etnafes-voyage.jpg",
            type: "image"
          },
          x: 0,
          y: 0,
          z: 0,
          rx: 0,
          rz: 0,
          ry: 90,
          connections: ["eIm7la", "eId9l0", "fK2dL7l"]
        },
        {
          key: "eIm7la",
          panorama: {
            source: "1.jpg",
            type: "cube"
          },
          x: 100,
          y: 0,
          z: 200,
          rx: 0,
          rz: 0,
          ry: 0,
          connections: ["M4wOy2s"]
        }
      ]
    };
  }
};
</script>