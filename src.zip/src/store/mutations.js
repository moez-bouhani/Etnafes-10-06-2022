let mutations = {

    SET_user(state, payload) {
        state.user = payload;
    },


}
export default mutations